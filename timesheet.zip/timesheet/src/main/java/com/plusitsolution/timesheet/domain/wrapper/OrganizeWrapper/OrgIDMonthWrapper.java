package com.plusitsolution.timesheet.domain.wrapper.OrganizeWrapper;

public class OrgIDMonthWrapper {
	
	private String orgID ;
	private int month ;
	private int year ;
	
	public String getOrgID() {
		return orgID;
	}
	public void setOrgID(String orgID) {
		this.orgID = orgID;
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	
	

}
