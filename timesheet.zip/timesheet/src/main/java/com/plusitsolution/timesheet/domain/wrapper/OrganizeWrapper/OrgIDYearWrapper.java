package com.plusitsolution.timesheet.domain.wrapper.OrganizeWrapper;

public class OrgIDYearWrapper {
	
	private String orgID ;
	private int year ;

	public String getOrgID() {
		return orgID;
	}

	public void setOrgID(String orgID) {
		this.orgID = orgID;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}
	

}
