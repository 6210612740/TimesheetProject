package com.plusitsolution.timesheet.domain.wrapper.OrganizeWrapper;

public class OrgIDWrapper {
	
	private String orgID ;

	public String getOrgID() {
		return orgID;
	}

	public void setOrgID(String orgID) {
		this.orgID = orgID;
	}
	
	

}
