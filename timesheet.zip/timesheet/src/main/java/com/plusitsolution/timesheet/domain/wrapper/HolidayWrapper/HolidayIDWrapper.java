package com.plusitsolution.timesheet.domain.wrapper.HolidayWrapper;

public class HolidayIDWrapper {
	
	private String holidayID;

	public String getHolidayID() {
		return holidayID;
	}

	public void setHolidayID(String holidayID) {
		this.holidayID = holidayID;
	}
	
	

}
