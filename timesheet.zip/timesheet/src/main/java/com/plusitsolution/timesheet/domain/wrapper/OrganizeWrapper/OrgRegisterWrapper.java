package com.plusitsolution.timesheet.domain.wrapper.OrganizeWrapper;

public class OrgRegisterWrapper {
	
	private String orgNameTh ;
	private String orgNameEng ;
	private String shortName ;
	private String orgAdress ;
	private String orgPic ;
	
	private String firstName;
	private String lastName;
	private String nickName ;
	private String password ;
	private String username;
	
	public String getOrgNameTh() {
		return orgNameTh;
	}
	public void setOrgNameTh(String orgNameTh) {
		this.orgNameTh = orgNameTh;
	}
	public String getOrgNameEng() {
		return orgNameEng;
	}
	public void setOrgNameEng(String orgNameEng) {
		this.orgNameEng = orgNameEng;
	}
	public String getShortName() {
		return shortName;
	}
	public void setShortName(String shortName) {
		this.shortName = shortName;
	}
	public String getOrgAdress() {
		return orgAdress;
	}
	public void setOrgAdress(String orgAdress) {
		this.orgAdress = orgAdress;
	}
	public String getOrgPic() {
		return orgPic;
	}
	public void setOrgPic(String orgPic) {
		this.orgPic = orgPic;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	

}
