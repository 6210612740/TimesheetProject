package com.plusitsolution.timesheet.domain.wrapper.MedicalWrapper;

public class MedicalIDWrapper {
	
	private String medID;

	public String getMedID() {
		return medID;
	}

	public void setMedID(String medID) {
		this.medID = medID;
	}
	
	

}
