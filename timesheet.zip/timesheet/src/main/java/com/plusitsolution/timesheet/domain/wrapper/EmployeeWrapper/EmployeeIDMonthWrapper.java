package com.plusitsolution.timesheet.domain.wrapper.EmployeeWrapper;

public class EmployeeIDMonthWrapper {
	
	private String empID ;
	private int month ;
	private int year ;
	public String getEmpID() {
		return empID;
	}
	public void setEmpID(String empID) {
		this.empID = empID;
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	
	

}
