package com.plusitsolution.timesheet.domain.wrapper.EmployeeWrapper;

public class EmployeeIDWrapper {

	private String empID ;

	public String getEmpID() {
		return empID;
	}

	public void setEmpID(String empID) {
		this.empID = empID;
	} 
	
	
	
}
