package com.plusitsolution.timesheet.domain.wrapper.LeaveWrapper;

public class LeaveIDWrapper {
	
	private String leaveID;

	public String getLeaveID() {
		return leaveID;
	}

	public void setLeaveID(String leaveID) {
		this.leaveID = leaveID;
	}
	
	

}
